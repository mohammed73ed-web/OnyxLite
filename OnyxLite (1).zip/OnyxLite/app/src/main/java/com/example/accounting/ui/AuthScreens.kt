@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.accounting.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import kotlinx.coroutines.launch

@Composable
fun LoginScreen(onDone: (mustChange: Boolean) -> Unit, vm: MainVm = hiltViewModel()) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var user by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp, Alignment.CenterVertically),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("المحاسب", style = MaterialTheme.typography.headlineLarge, color = MaterialTheme.colorScheme.primary)
        Text("تسجيل الدخول", style = MaterialTheme.typography.titleMedium)
        OutlinedTextField(user, { user = it }, Modifier.fillMaxWidth(), label = { Text("اسم المستخدم") }, singleLine = true)
        OutlinedTextField(
            pass, { pass = it }, Modifier.fillMaxWidth(), label = { Text("كلمة المرور") }, singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
        )
        Button(
            enabled = !busy && user.isNotBlank() && pass.isNotEmpty(),
            modifier = Modifier.fillMaxWidth(),
            onClick = {
                scope.launch {
                    busy = true
                    runCatching { vm.svc.login(user.trim(), pass) }
                        .onSuccess { onDone(it) }
                        .onFailure { ctx.toast(it.message ?: "حدث خطأ") }
                    busy = false
                }
            }
        ) { Text(if (busy) "جارٍ الدخول..." else "دخول") }
    }
}

@Composable
fun ChangePasswordScreen(onDone: () -> Unit, vm: MainVm = hiltViewModel()) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var p1 by remember { mutableStateOf("") }
    var p2 by remember { mutableStateOf("") }
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp, Alignment.CenterVertically)
    ) {
        Text("يجب تغيير كلمة المرور", style = MaterialTheme.typography.titleLarge)
        Text("لأسباب أمنية، اختر كلمة مرور جديدة قبل المتابعة.")
        OutlinedTextField(
            p1, { p1 = it }, Modifier.fillMaxWidth(), label = { Text("كلمة المرور الجديدة") }, singleLine = true,
            visualTransformation = PasswordVisualTransformation()
        )
        OutlinedTextField(
            p2, { p2 = it }, Modifier.fillMaxWidth(), label = { Text("تأكيد كلمة المرور") }, singleLine = true,
            visualTransformation = PasswordVisualTransformation()
        )
        Button(
            modifier = Modifier.fillMaxWidth(),
            onClick = {
                if (p1 != p2) { ctx.toast("كلمتا المرور غير متطابقتين"); return@Button }
                scope.launch {
                    runCatching { vm.svc.changePassword(p1) }
                        .onSuccess { onDone() }
                        .onFailure { ctx.toast(it.message ?: "حدث خطأ") }
                }
            }
        ) { Text("حفظ ومتابعة") }
    }
}
