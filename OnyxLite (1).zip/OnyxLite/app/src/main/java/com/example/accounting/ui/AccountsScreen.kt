@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.accounting.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.example.accounting.data.*
import kotlinx.coroutines.launch

@Composable
fun AccountsScreen(onBack: () -> Unit, vm: MainVm = hiltViewModel()) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val accounts by vm.svc.accountsFlow.collectAsState(initial = emptyList<Account>())
    val session by vm.sm.session.collectAsState()
    val canEdit = session?.permissions?.contains(Permission.ACCOUNT_EDIT) == true
    var query by remember { mutableStateOf("") }
    var editing by remember { mutableStateOf<Account?>(null) }
    var creating by remember { mutableStateOf(false) }
    val byId = remember(accounts) { accounts.associateBy { it.id } }
    fun depth(a: Account): Int { var d = 0; var p = a.parentId; while (p != null) { d++; p = byId[p]?.parentId }; return d }
    val key = query.westernDigits().trim()
    val shown = if (key.isEmpty()) accounts else accounts.filter { it.nameAr.contains(key) || it.code.startsWith(key) }

    AppScaffold(
        "دليل الحسابات", onBack,
        fab = { if (canEdit) FloatingActionButton(onClick = { creating = true }) { Icon(Icons.Default.Add, "حساب جديد") } }
    ) { pad ->
        Column(Modifier.padding(pad)) {
            OutlinedTextField(
                query, { query = it }, Modifier.fillMaxWidth().padding(12.dp),
                label = { Text("بحث بالاسم أو الرمز") }, singleLine = true
            )
            LazyColumn(contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)) {
                items(shown, key = { it.id }) { a ->
                    Row(
                        Modifier.fillMaxWidth()
                            .clickable(enabled = canEdit) { editing = a }
                            .padding(start = (if (key.isEmpty()) depth(a) * 16 else 0).dp, top = 8.dp, bottom = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(a.code, Modifier.width(72.dp), style = MaterialTheme.typography.bodySmall)
                        Text(
                            a.nameAr, Modifier.weight(1f),
                            fontWeight = if (a.isLeaf) FontWeight.Normal else FontWeight.Bold,
                            color = if (a.isActive) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.outline
                        )
                        Text(if (a.normalBalance == NormalBalance.DEBIT) "م" else "د", style = MaterialTheme.typography.bodySmall)
                    }
                    HorizontalDivider()
                }
            }
        }
    }

    if (creating || editing != null) {
        AccountDialog(
            initial = editing, accounts = accounts,
            onDismiss = { creating = false; editing = null },
            onSave = { acc ->
                scope.launch {
                    runCatching { vm.svc.saveAccount(acc) }
                        .onSuccess { creating = false; editing = null }
                        .onFailure { ctx.toast(it.message ?: "حدث خطأ") }
                }
            }
        )
    }
}

@Composable
private fun AccountDialog(initial: Account?, accounts: List<Account>, onDismiss: () -> Unit, onSave: (Account) -> Unit) {
    var code by remember { mutableStateOf(initial?.code ?: "") }
    var name by remember { mutableStateOf(initial?.nameAr ?: "") }
    var parent by remember { mutableStateOf(accounts.find { it.id == initial?.parentId }) }
    var type by remember { mutableStateOf(initial?.type ?: AccountType.ASSET) }
    var contra by remember { mutableStateOf(initial?.let { it.normalBalance != defaultNormal(it.type) } ?: false) }
    var leaf by remember { mutableStateOf(initial?.isLeaf ?: true) }
    var active by remember { mutableStateOf(initial?.isActive ?: true) }
    val effectiveType = parent?.type ?: type

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "حساب جديد" else "تعديل حساب") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    code, { code = it.westernDigits() }, label = { Text("الرمز") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )
                OutlinedTextField(name, { name = it }, label = { Text("اسم الحساب") }, singleLine = true)
                Text("الحساب الأب", style = MaterialTheme.typography.labelMedium)
                AccountPicker(
                    accounts.filter { !it.isLeaf && it.id != initial?.id }, parent, "بدون (حساب رئيسي)"
                ) { parent = it }
                if (parent != null) TextButton(onClick = { parent = null }) { Text("إزالة الحساب الأب") }
                if (parent == null) {
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        AccountType.values().forEach { t ->
                            FilterChip(selected = type == t, onClick = { type = t }, label = { Text(typeAr[t] ?: "") })
                        }
                    }
                } else Text("النوع: ${typeAr[effectiveType]} (موروث من الأب)")
                LabeledSwitch("طبيعة عكسية (حساب مقابل)", contra) { contra = it }
                LabeledSwitch("حساب فرعي (يقبل القيود)", leaf) { leaf = it }
                LabeledSwitch("فعّال", active) { active = it }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val base = defaultNormal(effectiveType)
                val normal = if (!contra) base else if (base == NormalBalance.DEBIT) NormalBalance.CREDIT else NormalBalance.DEBIT
                val acc = (initial ?: Account(code = "", nameAr = "", type = effectiveType, normalBalance = normal)).copy(
                    code = code.trim(), nameAr = name.trim(), parentId = parent?.id, type = effectiveType,
                    normalBalance = normal, isLeaf = leaf, isActive = active
                )
                onSave(acc)
            }) { Text("حفظ") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}
