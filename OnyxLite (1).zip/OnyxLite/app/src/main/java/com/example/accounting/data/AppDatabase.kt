package com.example.accounting.data

import androidx.room.Database
import androidx.room.RoomDatabase

const val DB_NAME = "accounting.db"

@Database(
    entities = [
        Account::class, JournalEntry::class, JournalLine::class, Branch::class,
        Role::class, RolePermission::class, User::class, UserBranch::class, AuditLog::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun accountDao(): AccountDao
    abstract fun entryDao(): EntryDao
    abstract fun lineDao(): LineDao
    abstract fun userDao(): UserDao
    abstract fun roleDao(): RoleDao
    abstract fun branchDao(): BranchDao
    abstract fun auditDao(): AuditDao
}

/** حماية على مستوى قاعدة البيانات: القيد المرحّل لا تُعدَّل سطوره ولا يُحذف حتى لو أخطأ الكود. */
val IMMUTABILITY_TRIGGERS = listOf(
    """CREATE TRIGGER IF NOT EXISTS trg_lines_no_update BEFORE UPDATE ON journal_lines
       WHEN EXISTS (SELECT 1 FROM journal_entries WHERE id = OLD.entryId AND status <> 'DRAFT')
       BEGIN SELECT RAISE(ABORT, 'posted entry is immutable'); END""",
    """CREATE TRIGGER IF NOT EXISTS trg_lines_no_delete BEFORE DELETE ON journal_lines
       WHEN EXISTS (SELECT 1 FROM journal_entries WHERE id = OLD.entryId AND status <> 'DRAFT')
       BEGIN SELECT RAISE(ABORT, 'posted entry is immutable'); END""",
    """CREATE TRIGGER IF NOT EXISTS trg_entries_no_delete BEFORE DELETE ON journal_entries
       WHEN OLD.status <> 'DRAFT'
       BEGIN SELECT RAISE(ABORT, 'posted entry cannot be deleted'); END"""
)
