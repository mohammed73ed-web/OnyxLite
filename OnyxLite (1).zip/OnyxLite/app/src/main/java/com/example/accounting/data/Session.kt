package com.example.accounting.data

import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

data class Session(
    val user: User,
    val permissions: Set<Permission>,
    val allowedBranchIds: Set<Long>,
    val currentBranchId: Long
)

@Singleton
class SessionManager @Inject constructor() {
    private val _session = MutableStateFlow<Session?>(null)
    val session: StateFlow<Session?> = _session.asStateFlow()

    fun start(s: Session) { _session.value = s }
    fun clear() { _session.value = null }
    fun can(p: Permission) = _session.value?.permissions?.contains(p) == true

    fun requireBranch(id: Long) {
        val s = _session.value ?: error("غير مسجّل الدخول")
        require(id in s.allowedBranchIds) { "لا تملك صلاحية هذا الفرع" }
    }

    fun switchBranch(id: Long) {
        requireBranch(id)
        _session.update { it?.copy(currentBranchId = id) }
    }

    fun addBranch(id: Long) { _session.update { it?.copy(allowedBranchIds = it.allowedBranchIds + id) } }
    fun updateUser(u: User) { _session.update { it?.copy(user = u) } }
}
