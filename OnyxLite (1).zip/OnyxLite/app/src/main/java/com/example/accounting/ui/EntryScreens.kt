@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.accounting.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.example.accounting.data.*
import kotlinx.coroutines.launch

@Composable
fun EntriesScreen(onBack: () -> Unit, onOpen: (Long) -> Unit, vm: MainVm = hiltViewModel()) {
    val rows by vm.svc.entriesFlow.collectAsState(initial = emptyList<EntryRow>())
    val canCreate = vm.sm.can(Permission.ENTRY_CREATE)
    AppScaffold(
        "قيود اليومية", onBack,
        fab = { if (canCreate) FloatingActionButton(onClick = { onOpen(0) }) { Icon(Icons.Default.Add, "قيد جديد") } }
    ) { pad ->
        if (rows.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(pad), contentAlignment = Alignment.Center) { Text("لا توجد قيود في هذا الفرع") }
        } else {
            LazyColumn(
                Modifier.padding(pad), contentPadding = PaddingValues(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(rows, key = { it.entry.id }) { r ->
                    Card(Modifier.fillMaxWidth().clickable { onOpen(r.entry.id) }) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row {
                                Text("قيد رقم ${r.entry.entryNo}", fontWeight = FontWeight.Bold)
                                Spacer(Modifier.weight(1f))
                                Text(statusAr[r.entry.status] ?: "", color = MaterialTheme.colorScheme.secondary)
                            }
                            Text(r.entry.description, maxLines = 2)
                            Row {
                                Text(Dates.format(r.entry.date), style = MaterialTheme.typography.bodySmall)
                                Spacer(Modifier.weight(1f))
                                Text(Money.format(r.total), style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                    }
                }
            }
        }
    }
}

private data class LineUi(val account: Account? = null, val debit: String = "", val credit: String = "", val note: String = "")

@Composable
fun EntryScreen(entryId: Long, onBack: () -> Unit, vm: MainVm = hiltViewModel()) {
    val svc = vm.svc
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val session by vm.sm.session.collectAsState()
    val perms = session?.permissions ?: emptySet()
    val accounts by svc.accountsFlow.collectAsState(initial = emptyList<Account>())
    val leafAccounts = remember(accounts) { accounts.filter { it.isLeaf && it.isActive } }

    var entry by remember { mutableStateOf<JournalEntry?>(null) }
    var date by remember { mutableStateOf(Dates.format(Dates.today())) }
    var desc by remember { mutableStateOf("") }
    val lines = remember { mutableStateListOf(LineUi(), LineUi()) }
    var loaded by remember { mutableStateOf(entryId == 0L) }
    var confirm by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(entryId, accounts) {
        if (entryId != 0L && !loaded && accounts.isNotEmpty()) {
            runCatching { svc.loadEntry(entryId) }
                .onSuccess { (e, ls) ->
                    entry = e; date = Dates.format(e.date); desc = e.description
                    lines.clear()
                    lines.addAll(ls.map { l ->
                        LineUi(
                            accounts.find { it.id == l.accountId },
                            if (l.debit > 0) Money.format(l.debit) else "",
                            if (l.credit > 0) Money.format(l.credit) else "",
                            l.note ?: ""
                        )
                    })
                    loaded = true
                }
                .onFailure { ctx.toast(it.message ?: "حدث خطأ"); onBack() }
        }
    }

    val e = entry
    val editable = loaded && (e == null || e.status == EntryStatus.DRAFT) &&
        (if (e == null) Permission.ENTRY_CREATE in perms else Permission.ENTRY_EDIT in perms)
    val totalD = lines.sumOf { Money.parse(it.debit) ?: 0L }
    val totalC = lines.sumOf { Money.parse(it.credit) ?: 0L }
    val balanced = totalD == totalC && totalD > 0

    fun buildInputs(): List<LineInput> = lines
        .filter { it.account != null || it.debit.isNotBlank() || it.credit.isNotBlank() }
        .map { l ->
            LineInput(
                requireNotNull(l.account) { "اختر الحساب في كل سطر" }.id,
                Money.parse(l.debit) ?: throw IllegalArgumentException("مبلغ مدين غير صحيح"),
                Money.parse(l.credit) ?: throw IllegalArgumentException("مبلغ دائن غير صحيح"),
                l.note.ifBlank { null }
            )
        }

    fun run(post: Boolean) {
        scope.launch {
            runCatching {
                val d = Dates.parse(date) ?: throw IllegalArgumentException("صيغة التاريخ yyyy-MM-dd")
                val id = svc.saveEntry(entryId, d, desc, buildInputs())
                if (post) {
                    try { svc.postEntry(id) } catch (ex: Exception) { ctx.toast("حُفظ كمسودة، تعذّر الترحيل: ${ex.message}") }
                }
            }.onSuccess { onBack() }.onFailure { ctx.toast(it.message ?: "حدث خطأ") }
        }
    }

    fun simple(block: suspend () -> Unit) {
        scope.launch { runCatching { block() }.onSuccess { onBack() }.onFailure { ctx.toast(it.message ?: "حدث خطأ") } }
    }

    AppScaffold(if (e == null) "قيد جديد" else "قيد رقم ${e.entryNo}", onBack) { pad ->
        Column(
            Modifier.padding(pad).padding(12.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (e != null) {
                Text(
                    "الحالة: ${statusAr[e.status]}" + if (e.reversedEntryId != null) " (قيد عكسي)" else "",
                    color = MaterialTheme.colorScheme.secondary, fontWeight = FontWeight.Bold
                )
            }
            OutlinedTextField(
                date, { date = it }, Modifier.fillMaxWidth(), label = { Text("التاريخ (yyyy-MM-dd)") },
                singleLine = true, enabled = editable
            )
            OutlinedTextField(desc, { desc = it }, Modifier.fillMaxWidth(), label = { Text("البيان") }, enabled = editable)

            lines.forEachIndexed { i, l ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        AccountPicker(leafAccounts, l.account, "اختر الحساب", enabled = editable) { lines[i] = l.copy(account = it) }
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                            OutlinedTextField(
                                l.debit, { v -> lines[i] = l.copy(debit = v, credit = if (v.isNotBlank()) "" else l.credit) },
                                Modifier.weight(1f), label = { Text("مدين") }, singleLine = true, enabled = editable,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
                            )
                            OutlinedTextField(
                                l.credit, { v -> lines[i] = l.copy(credit = v, debit = if (v.isNotBlank()) "" else l.debit) },
                                Modifier.weight(1f), label = { Text("دائن") }, singleLine = true, enabled = editable,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
                            )
                            if (editable && lines.size > 2) {
                                IconButton(onClick = { lines.removeAt(i) }) { Icon(Icons.Default.Delete, "حذف السطر") }
                            }
                        }
                        OutlinedTextField(
                            l.note, { lines[i] = l.copy(note = it) }, Modifier.fillMaxWidth(),
                            label = { Text("ملاحظة (اختياري)") }, singleLine = true, enabled = editable
                        )
                    }
                }
            }
            if (editable) OutlinedButton(onClick = { lines.add(LineUi()) }, Modifier.fillMaxWidth()) { Text("+ إضافة سطر") }

            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Text("إجمالي المدين: ${Money.format(totalD)}")
                    Text("إجمالي الدائن: ${Money.format(totalC)}")
                    Text(
                        if (balanced) "القيد متوازن ✓" else "الفرق: ${Money.format(kotlin.math.abs(totalD - totalC))}",
                        color = if (balanced) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            if (editable) {
                Button(onClick = { run(false) }, Modifier.fillMaxWidth()) { Text("حفظ كمسودة") }
                if (Permission.ENTRY_POST in perms) {
                    FilledTonalButton(onClick = { run(true) }, Modifier.fillMaxWidth()) { Text("حفظ وترحيل") }
                }
                if (e != null && Permission.ENTRY_DELETE_DRAFT in perms) {
                    TextButton(onClick = { confirm = "delete" }, Modifier.fillMaxWidth()) {
                        Text("حذف المسودة", color = MaterialTheme.colorScheme.error)
                    }
                }
            } else if (e != null && e.status == EntryStatus.POSTED && e.reversedEntryId == null && Permission.ENTRY_REVERSE in perms) {
                OutlinedButton(onClick = { confirm = "reverse" }, Modifier.fillMaxWidth()) { Text("عكس القيد (قيد عكسي)") }
            }
        }
    }

    when (confirm) {
        "delete" -> ConfirmDialog("حذف المسودة", "سيُحذف القيد نهائياً. متابعة؟", { confirm = null; simple { svc.deleteDraft(entryId) } }, { confirm = null })
        "reverse" -> ConfirmDialog("عكس القيد", "سيُنشأ قيد عكسي مرحّل بتاريخ اليوم ويُعلَّم الأصلي كمعكوس. متابعة؟", { confirm = null; simple { svc.reverseEntry(entryId) } }, { confirm = null })
    }
}
