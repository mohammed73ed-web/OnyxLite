@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.accounting.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.example.accounting.data.Branch
import com.example.accounting.data.Permission

private data class Tile(val title: String, val route: String, val perm: Permission, val hint: String)

@Composable
fun HomeScreen(onNavigate: (String) -> Unit, vm: MainVm = hiltViewModel()) {
    val session by vm.sm.session.collectAsState()
    val branches by vm.svc.myBranchesFlow.collectAsState(initial = emptyList<Branch>())
    var menu by remember { mutableStateOf(false) }
    val s = session ?: return
    val tiles = listOf(
        Tile("دليل الحسابات", "accounts", Permission.ACCOUNT_VIEW, "الشجرة الهرمية للحسابات"),
        Tile("قيود اليومية", "entries", Permission.ENTRY_VIEW, "إنشاء وترحيل وعكس القيود"),
        Tile("ميزان المراجعة", "trial", Permission.REPORT_VIEW, "أرصدة افتتاحية وحركة وختامية"),
        Tile("كشف حساب", "statement", Permission.REPORT_VIEW, "حركة حساب مع الرصيد الجاري"),
        Tile("المستخدمون", "users", Permission.USER_MANAGE, "الأدوار والفروع المسموحة"),
        Tile("الفروع", "branches", Permission.BRANCH_MANAGE, "إضافة وتعطيل الفروع"),
        Tile("نسخ احتياطي واستعادة", "backup", Permission.BACKUP_RESTORE, "حفظ قاعدة البيانات واسترجاعها")
    ).filter { it.perm in s.permissions }

    AppScaffold(
        title = "المحاسب",
        onBack = null,
        actions = {
            Box {
                TextButton(onClick = { menu = true }) {
                    Text(branches.find { it.id == s.currentBranchId }?.nameAr ?: "الفرع")
                }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    branches.forEach { b ->
                        DropdownMenuItem(text = { Text(b.nameAr) }, onClick = { vm.svc.switchBranch(b.id); menu = false })
                    }
                }
            }
            TextButton(onClick = { vm.svc.logout() }) { Text("خروج") }
        }
    ) { pad ->
        Column(Modifier.padding(pad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("مرحباً ${s.user.fullName}", style = MaterialTheme.typography.titleMedium)
            tiles.forEach { t ->
                Card(Modifier.fillMaxWidth().clickable { onNavigate(t.route) }) {
                    Column(Modifier.padding(16.dp)) {
                        Text(t.title, style = MaterialTheme.typography.titleMedium)
                        Text(t.hint, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}
