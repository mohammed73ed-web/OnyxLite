@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.accounting.ui

import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import com.example.accounting.data.*
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(primary = Color(0xFF1F3A5F), secondary = Color(0xFF3B6EA5)),
        content = content
    )
}

@HiltViewModel
class MainVm @Inject constructor(
    val svc: AccountingService,
    val sm: SessionManager,
    val backup: BackupManager
) : ViewModel()

fun Context.toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

val typeAr = mapOf(
    AccountType.ASSET to "أصول", AccountType.LIABILITY to "خصوم", AccountType.EQUITY to "حقوق ملكية",
    AccountType.REVENUE to "إيرادات", AccountType.EXPENSE to "مصروفات"
)
val statusAr = mapOf(EntryStatus.DRAFT to "مسودة", EntryStatus.POSTED to "مرحّل", EntryStatus.REVERSED to "معكوس")

@Composable
fun AppScaffold(
    title: String,
    onBack: (() -> Unit)?,
    actions: @Composable RowScope.() -> Unit = {},
    fab: @Composable () -> Unit = {},
    content: @Composable (PaddingValues) -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(title) },
                navigationIcon = {
                    if (onBack != null) IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "رجوع") }
                },
                actions = actions
            )
        },
        floatingActionButton = fab,
        content = content
    )
}

@Composable
fun LabeledSwitch(text: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Switch(checked = checked, onCheckedChange = onChange)
        Spacer(Modifier.width(8.dp))
        Text(text)
    }
}

@Composable
fun ConfirmDialog(title: String, text: String, onConfirm: () -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { Text(text) },
        confirmButton = { TextButton(onClick = onConfirm) { Text("تأكيد") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

@Composable
fun DateRangeFields(from: String, to: String, onFrom: (String) -> Unit, onTo: (String) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(from, onFrom, Modifier.weight(1f), label = { Text("من (yyyy-MM-dd)") }, singleLine = true)
        OutlinedTextField(to, onTo, Modifier.weight(1f), label = { Text("إلى (yyyy-MM-dd)") }, singleLine = true)
    }
}

@Composable
fun AccountPicker(
    accounts: List<Account>,
    selected: Account?,
    label: String,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    onSelect: (Account) -> Unit
) {
    var open by remember { mutableStateOf(false) }
    OutlinedButton(onClick = { open = true }, enabled = enabled, modifier = modifier.fillMaxWidth()) {
        Text(selected?.let { "${it.code} - ${it.nameAr}" } ?: label, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
    if (open) {
        var q by remember { mutableStateOf("") }
        val key = q.westernDigits().trim()
        AlertDialog(
            onDismissRequest = { open = false },
            title = { Text(label) },
            text = {
                Column {
                    OutlinedTextField(q, { q = it }, label = { Text("بحث بالاسم أو الرمز") }, singleLine = true)
                    LazyColumn(Modifier.heightIn(max = 360.dp)) {
                        items(accounts.filter { key.isEmpty() || it.nameAr.contains(key) || it.code.startsWith(key) }, key = { it.id }) { a ->
                            Text(
                                "${a.code}   ${a.nameAr}",
                                Modifier.fillMaxWidth().clickable { onSelect(a); open = false }.padding(vertical = 12.dp)
                            )
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { open = false }) { Text("إغلاق") } }
        )
    }
}
