package com.example.accounting.data

import androidx.room.Dao
import androidx.room.Embedded
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

data class EntryRow(@Embedded val entry: JournalEntry, val total: Long)
data class UserRow(@Embedded val user: User, val roleName: String)
data class TrialRow(val code: String, val nameAr: String, val opening: Long, val debit: Long, val credit: Long)
data class StmtRow(val date: Long, val entryNo: Long, val description: String, val note: String?, val debit: Long, val credit: Long)

@Dao
interface AccountDao {
    @Insert suspend fun insert(a: Account): Long
    @Update suspend fun update(a: Account)
    @Query("SELECT COUNT(*) FROM accounts") suspend fun count(): Int
    @Query("SELECT * FROM accounts ORDER BY code") fun observeAll(): Flow<List<Account>>
    @Query("SELECT * FROM accounts WHERE id = :id") suspend fun get(id: Long): Account?
    @Query("SELECT * FROM accounts WHERE code = :c LIMIT 1") suspend fun byCode(c: String): Account?
    @Query("SELECT * FROM accounts WHERE id IN (:ids)") suspend fun byIds(ids: List<Long>): List<Account>
    @Query("SELECT COUNT(*) FROM accounts WHERE parentId = :id") suspend fun childCount(id: Long): Int
    @Query("SELECT COUNT(*) FROM journal_lines WHERE accountId = :id") suspend fun lineCount(id: Long): Int
}

@Dao
interface EntryDao {
    @Insert suspend fun insert(e: JournalEntry): Long
    @Update suspend fun update(e: JournalEntry)
    @Query("SELECT * FROM journal_entries WHERE id = :id") suspend fun get(id: Long): JournalEntry?
    @Query("DELETE FROM journal_entries WHERE id = :id") suspend fun delete(id: Long)
    @Query("SELECT COALESCE(MAX(entryNo), 0) + 1 FROM journal_entries WHERE branchId = :b") suspend fun nextNo(b: Long): Long
    @Query(
        """SELECT e.*, COALESCE((SELECT SUM(debit) FROM journal_lines WHERE entryId = e.id), 0) AS total
           FROM journal_entries e WHERE e.branchId = :branchId ORDER BY e.date DESC, e.id DESC"""
    )
    fun observe(branchId: Long): Flow<List<EntryRow>>
}

@Dao
interface LineDao {
    @Insert suspend fun insertAll(l: List<JournalLine>)
    @Query("DELETE FROM journal_lines WHERE entryId = :id") suspend fun deleteByEntry(id: Long)
    @Query("SELECT * FROM journal_lines WHERE entryId = :id ORDER BY id") suspend fun byEntry(id: Long): List<JournalLine>

    // يشمل POSTED و REVERSED معاً: القيد الأصلي المعكوس والقيد العكسي يتقابلان فيصافي أثرهما
    @Query(
        """SELECT a.code AS code, a.nameAr AS nameAr,
             COALESCE(SUM(CASE WHEN e.date < :from THEN l.debit - l.credit ELSE 0 END), 0) AS opening,
             COALESCE(SUM(CASE WHEN e.date >= :from THEN l.debit ELSE 0 END), 0) AS debit,
             COALESCE(SUM(CASE WHEN e.date >= :from THEN l.credit ELSE 0 END), 0) AS credit
           FROM journal_lines l
           JOIN journal_entries e ON e.id = l.entryId
           JOIN accounts a ON a.id = l.accountId
           WHERE e.status IN ('POSTED','REVERSED') AND e.branchId IN (:branchIds) AND e.date <= :to
           GROUP BY a.id ORDER BY a.code"""
    )
    suspend fun trialBalance(branchIds: List<Long>, from: Long, to: Long): List<TrialRow>

    @Query(
        """SELECT COALESCE(SUM(l.debit - l.credit), 0) FROM journal_lines l
           JOIN journal_entries e ON e.id = l.entryId
           WHERE l.accountId = :acc AND e.status IN ('POSTED','REVERSED')
             AND e.branchId IN (:branchIds) AND e.date < :from"""
    )
    suspend fun opening(acc: Long, branchIds: List<Long>, from: Long): Long

    @Query(
        """SELECT e.date AS date, e.entryNo AS entryNo, e.description AS description,
                  l.note AS note, l.debit AS debit, l.credit AS credit
           FROM journal_lines l JOIN journal_entries e ON e.id = l.entryId
           WHERE l.accountId = :acc AND e.status IN ('POSTED','REVERSED')
             AND e.branchId IN (:branchIds) AND e.date BETWEEN :from AND :to
           ORDER BY e.date, e.id, l.id"""
    )
    suspend fun statement(acc: Long, branchIds: List<Long>, from: Long, to: Long): List<StmtRow>
}

@Dao
interface UserDao {
    @Insert suspend fun insert(u: User): Long
    @Update suspend fun update(u: User)
    @Query("SELECT COUNT(*) FROM users") suspend fun count(): Int
    @Query("SELECT * FROM users WHERE username = :n COLLATE NOCASE LIMIT 1") suspend fun byUsername(n: String): User?
    @Query("SELECT * FROM users WHERE id = :id") suspend fun get(id: Long): User?
    @Query("SELECT u.*, r.name AS roleName FROM users u JOIN roles r ON r.id = u.roleId ORDER BY u.username")
    fun observeRows(): Flow<List<UserRow>>
    @Query("SELECT branchId FROM user_branches WHERE userId = :id") suspend fun branchIds(id: Long): List<Long>
    @Query("DELETE FROM user_branches WHERE userId = :id") suspend fun clearBranches(id: Long)
    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun addBranches(list: List<UserBranch>)
}

@Dao
interface RoleDao {
    @Insert suspend fun insert(r: Role): Long
    @Insert suspend fun insertPermissions(list: List<RolePermission>)
    @Query("SELECT permission FROM role_permissions WHERE roleId = :id") suspend fun permissions(id: Long): List<Permission>
    @Query("SELECT * FROM roles ORDER BY id") fun observeAll(): Flow<List<Role>>
}

@Dao
interface BranchDao {
    @Insert suspend fun insert(b: Branch): Long
    @Update suspend fun update(b: Branch)
    @Query("SELECT * FROM branches ORDER BY code") fun observeAll(): Flow<List<Branch>>
    @Query("SELECT * FROM branches WHERE id = :id") suspend fun get(id: Long): Branch?
    @Query("SELECT * FROM branches WHERE id IN (:ids)") suspend fun byIds(ids: List<Long>): List<Branch>
}

@Dao
interface AuditDao {
    @Insert suspend fun insert(a: AuditLog)
}
