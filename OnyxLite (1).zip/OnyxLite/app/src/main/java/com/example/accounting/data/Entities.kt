package com.example.accounting.data

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import java.util.UUID

enum class AccountType { ASSET, LIABILITY, EQUITY, REVENUE, EXPENSE }
enum class NormalBalance { DEBIT, CREDIT }
enum class EntryStatus { DRAFT, POSTED, REVERSED }

enum class Permission {
    ACCOUNT_VIEW, ACCOUNT_EDIT,
    ENTRY_VIEW, ENTRY_CREATE, ENTRY_EDIT, ENTRY_DELETE_DRAFT, ENTRY_POST, ENTRY_REVERSE,
    REPORT_VIEW, USER_MANAGE, BRANCH_MANAGE, BACKUP_RESTORE
}

fun defaultNormal(t: AccountType) =
    if (t == AccountType.ASSET || t == AccountType.EXPENSE) NormalBalance.DEBIT else NormalBalance.CREDIT

@Entity(tableName = "accounts", indices = [Index("code", unique = true), Index("parentId")])
data class Account(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val uuid: String = UUID.randomUUID().toString(),
    val code: String,
    val nameAr: String,
    val parentId: Long? = null,
    val type: AccountType,
    val normalBalance: NormalBalance,
    val isLeaf: Boolean = true,
    val currencyCode: String = "YER",
    val isActive: Boolean = true
)

@Entity(
    tableName = "journal_entries",
    indices = [Index(value = ["branchId", "entryNo"], unique = true), Index("date")]
)
data class JournalEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val uuid: String = UUID.randomUUID().toString(),
    val entryNo: Long,
    val date: Long,                       // بداية اليوم بالتوقيت المحلي (ملي ثانية)
    val description: String,
    val status: EntryStatus = EntryStatus.DRAFT,
    val reversedEntryId: Long? = null,    // إن كان هذا قيداً عكسياً: رقم القيد الأصلي
    val branchId: Long,
    val createdBy: Long,
    val postedBy: Long? = null,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "journal_lines",
    foreignKeys = [
        ForeignKey(entity = JournalEntry::class, parentColumns = ["id"], childColumns = ["entryId"], onDelete = ForeignKey.CASCADE),
        ForeignKey(entity = Account::class, parentColumns = ["id"], childColumns = ["accountId"], onDelete = ForeignKey.RESTRICT)
    ],
    indices = [Index("entryId"), Index("accountId")]
)
data class JournalLine(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val entryId: Long,
    val accountId: Long,
    val debit: Long = 0,                  // بأصغر وحدة (×100)
    val credit: Long = 0,
    val currencyCode: String = "YER",
    val exchangeRate: Double = 1.0,
    val note: String? = null
)

@Entity(tableName = "branches", indices = [Index("code", unique = true)])
data class Branch(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val uuid: String = UUID.randomUUID().toString(),
    val code: String,
    val nameAr: String,
    val isActive: Boolean = true
)

@Entity(tableName = "roles", indices = [Index("name", unique = true)])
data class Role(@PrimaryKey(autoGenerate = true) val id: Long = 0, val name: String)

@Entity(
    tableName = "role_permissions", primaryKeys = ["roleId", "permission"],
    foreignKeys = [ForeignKey(entity = Role::class, parentColumns = ["id"], childColumns = ["roleId"], onDelete = ForeignKey.CASCADE)]
)
data class RolePermission(val roleId: Long, val permission: Permission)

@Entity(tableName = "users", indices = [Index("username", unique = true)])
data class User(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val username: String,
    val fullName: String,
    val passwordHash: String,
    val salt: String,
    val roleId: Long,
    val isActive: Boolean = true,
    val mustChangePassword: Boolean = false
)

@Entity(tableName = "user_branches", primaryKeys = ["userId", "branchId"], indices = [Index("branchId")])
data class UserBranch(val userId: Long, val branchId: Long)

@Entity(tableName = "audit_log")
data class AuditLog(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userId: Long,
    val branchId: Long,
    val action: String,
    val entityType: String,
    val entityId: Long?,
    val timestamp: Long = System.currentTimeMillis()
)
