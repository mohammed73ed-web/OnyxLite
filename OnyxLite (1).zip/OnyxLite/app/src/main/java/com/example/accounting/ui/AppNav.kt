package com.example.accounting.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.collectAsState
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument

@Composable
fun AppNav() {
    val nav = rememberNavController()
    val vm: MainVm = hiltViewModel()
    val session by vm.sm.session.collectAsState()

    // عند تسجيل الخروج نعود لشاشة الدخول ونمسح كل المكدس
    LaunchedEffect(session) {
        if (session == null && nav.currentDestination?.route != "login") {
            nav.navigate("login") { popUpTo(nav.graph.id) { inclusive = true } }
        }
    }

    val back: () -> Unit = { nav.popBackStack() }
    NavHost(nav, startDestination = "login") {
        composable("login") {
            LoginScreen { mustChange ->
                nav.navigate(if (mustChange) "changePw" else "home") { popUpTo("login") { inclusive = true } }
            }
        }
        composable("changePw") {
            ChangePasswordScreen { nav.navigate("home") { popUpTo("changePw") { inclusive = true } } }
        }
        composable("home") { HomeScreen { nav.navigate(it) } }
        composable("accounts") { AccountsScreen(back) }
        composable("entries") { EntriesScreen(back) { id -> nav.navigate("entry/$id") } }
        composable("entry/{id}", arguments = listOf(navArgument("id") { type = NavType.LongType })) {
            EntryScreen(it.arguments?.getLong("id") ?: 0L, back)
        }
        composable("trial") { TrialBalanceScreen(back) }
        composable("statement") { StatementScreen(back) }
        composable("users") { UsersScreen(back) }
        composable("branches") { BranchesScreen(back) }
        composable("backup") { BackupScreen(back) }
    }
}
