package com.example.accounting.data

import android.util.Base64
import java.math.BigDecimal
import java.math.RoundingMode
import java.security.MessageDigest
import java.security.SecureRandom
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.util.Locale
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/** تحويل الأرقام العربية-الهندية إلى لاتينية حتى يقبلها المحلل. */
fun String.westernDigits(): String = map {
    when (it) {
        in '\u0660'..'\u0669' -> '0' + (it - '\u0660')
        in '\u06F0'..'\u06F9' -> '0' + (it - '\u06F0')
        '\u066B', '\u060C' -> '.'
        else -> it
    }
}.joinToString("")

/** المبالغ تُخزَّن كأعداد صحيحة بأصغر وحدة (×100). لا Double في المحاسبة. */
object Money {
    private val fmt get() = DecimalFormat("#,##0.00", DecimalFormatSymbols(Locale.US))

    /** يعيد 0 للنص الفارغ، و null إن كان غير صالح أو سالباً. */
    fun parse(s: String): Long? {
        val t = s.westernDigits().trim().replace(",", "")
        if (t.isEmpty()) return 0L
        val v = t.toBigDecimalOrNull() ?: return null
        if (v.signum() < 0) return null
        return v.setScale(2, RoundingMode.HALF_UP).movePointRight(2).toLong()
    }

    fun format(v: Long): String = fmt.format(BigDecimal(v).movePointLeft(2))

    /** الرصيد الصافي: موجب = مدين، سالب = دائن. */
    fun signed(net: Long): String = when {
        net > 0 -> "${format(net)} م"
        net < 0 -> "${format(-net)} د"
        else -> "0.00"
    }
}

object Dates {
    private val zone get() = ZoneId.systemDefault()
    private fun LocalDate.ms() = atStartOfDay(zone).toInstant().toEpochMilli()

    fun today(): Long = LocalDate.now().ms()
    fun startOfYear(): Long = LocalDate.now().withDayOfYear(1).ms()
    fun parse(s: String): Long? = runCatching { LocalDate.parse(s.westernDigits().trim()).ms() }.getOrNull()
    fun format(ms: Long): String = Instant.ofEpochMilli(ms).atZone(zone).toLocalDate().toString()
}

object PasswordHasher {
    private const val ITERATIONS = 120_000

    fun newSalt(): String {
        val b = ByteArray(16)
        SecureRandom().nextBytes(b)
        return Base64.encodeToString(b, Base64.NO_WRAP)
    }

    fun hash(password: String, salt: String): String {
        val spec = PBEKeySpec(password.toCharArray(), Base64.decode(salt, Base64.NO_WRAP), ITERATIONS, 256)
        val bytes = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        return Base64.encodeToString(bytes, Base64.NO_WRAP)
    }

    fun verify(password: String, salt: String, expected: String): Boolean =
        MessageDigest.isEqual(hash(password, salt).toByteArray(), expected.toByteArray())
}
