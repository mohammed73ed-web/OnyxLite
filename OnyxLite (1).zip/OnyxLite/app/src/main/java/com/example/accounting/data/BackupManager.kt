package com.example.accounting.data

import android.content.Context
import android.net.Uri
import dagger.hilt.android.qualifiers.ApplicationContext
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Singleton
class BackupManager @Inject constructor(
    @ApplicationContext private val ctx: Context,
    private val db: AppDatabase,
    private val sm: SessionManager
) {
    private val dbFile: File get() = ctx.getDatabasePath(DB_NAME)

    suspend fun backup(uri: Uri) = withContext(Dispatchers.IO) {
        check(sm.can(Permission.BACKUP_RESTORE)) { "لا تملك الصلاحية المطلوبة" }
        db.openHelper.writableDatabase.query("PRAGMA wal_checkpoint(FULL)").use { it.moveToFirst() }
        val out = ctx.contentResolver.openOutputStream(uri) ?: error("تعذّر فتح الملف للكتابة")
        out.use { o -> dbFile.inputStream().use { it.copyTo(o) } }
    }

    /** بعد الاستعادة يجب إغلاق التطبيق وإعادة تشغيله. */
    suspend fun restore(uri: Uri) = withContext(Dispatchers.IO) {
        check(sm.can(Permission.BACKUP_RESTORE)) { "لا تملك الصلاحية المطلوبة" }
        val header = ByteArray(16)
        (ctx.contentResolver.openInputStream(uri) ?: error("تعذّر فتح الملف")).use { it.read(header) }
        check(String(header, Charsets.ISO_8859_1) == "SQLite format 3\u0000") { "الملف ليس نسخة احتياطية صالحة" }
        db.close()
        dbFile.copyTo(File(dbFile.path + ".before-restore"), overwrite = true)
        File(dbFile.path + "-wal").delete()
        File(dbFile.path + "-shm").delete()
        (ctx.contentResolver.openInputStream(uri) ?: error("تعذّر فتح الملف")).use { i ->
            dbFile.outputStream().use { i.copyTo(it) }
        }
    }
}
