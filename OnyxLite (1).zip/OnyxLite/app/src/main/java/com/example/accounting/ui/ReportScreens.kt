@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.accounting.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.example.accounting.data.*
import kotlinx.coroutines.launch

@Composable
private fun Cell(label: String, value: String, modifier: Modifier) {
    Column(modifier) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
        Text(value, style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
fun TrialBalanceScreen(onBack: () -> Unit, vm: MainVm = hiltViewModel()) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var from by remember { mutableStateOf(Dates.format(Dates.startOfYear())) }
    var to by remember { mutableStateOf(Dates.format(Dates.today())) }
    var all by remember { mutableStateOf(false) }
    var rows by remember { mutableStateOf<List<TrialRow>?>(null) }

    AppScaffold("ميزان المراجعة", onBack) { pad ->
        Column(Modifier.padding(pad).padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            DateRangeFields(from, to, { from = it }, { to = it })
            LabeledSwitch("كل الفروع المسموحة (بدل الفرع الحالي)", all) { all = it }
            Button(modifier = Modifier.fillMaxWidth(), onClick = {
                scope.launch {
                    runCatching {
                        vm.svc.trialBalance(
                            Dates.parse(from) ?: error("تاريخ البداية غير صحيح"),
                            Dates.parse(to) ?: error("تاريخ النهاية غير صحيح"), all
                        )
                    }.onSuccess { rows = it }.onFailure { ctx.toast(it.message ?: "حدث خطأ") }
                }
            }) { Text("عرض") }

            rows?.let { list ->
                val sd = list.sumOf { it.debit }
                val sc = list.sumOf { it.credit }
                val so = list.sumOf { it.opening }
                val balanced = sd == sc && so == 0L
                Text(
                    if (balanced) "الميزان متوازن ✓" else "تنبيه: الميزان غير متوازن، راجع القيود",
                    color = if (balanced) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
                    fontWeight = FontWeight.Bold
                )
                LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(list, key = { it.code }) { r ->
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(10.dp)) {
                                Text("${r.code}  ${r.nameAr}", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                                Row(Modifier.fillMaxWidth()) {
                                    Cell("افتتاحي", Money.signed(r.opening), Modifier.weight(1f))
                                    Cell("مدين", Money.format(r.debit), Modifier.weight(1f))
                                    Cell("دائن", Money.format(r.credit), Modifier.weight(1f))
                                    Cell("ختامي", Money.signed(r.opening + r.debit - r.credit), Modifier.weight(1f))
                                }
                            }
                        }
                    }
                    item {
                        Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                            Column(Modifier.padding(10.dp)) {
                                Text("الإجمالي", fontWeight = FontWeight.Bold)
                                Row(Modifier.fillMaxWidth()) {
                                    Cell("افتتاحي", Money.signed(so), Modifier.weight(1f))
                                    Cell("مدين", Money.format(sd), Modifier.weight(1f))
                                    Cell("دائن", Money.format(sc), Modifier.weight(1f))
                                    Cell("ختامي", Money.signed(so + sd - sc), Modifier.weight(1f))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun StatementScreen(onBack: () -> Unit, vm: MainVm = hiltViewModel()) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val accounts by vm.svc.accountsFlow.collectAsState(initial = emptyList<Account>())
    val leaf = remember(accounts) { accounts.filter { it.isLeaf } }
    var account by remember { mutableStateOf<Account?>(null) }
    var from by remember { mutableStateOf(Dates.format(Dates.startOfYear())) }
    var to by remember { mutableStateOf(Dates.format(Dates.today())) }
    var all by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf<Pair<Long, List<StmtRow>>?>(null) }

    AppScaffold("كشف حساب", onBack) { pad ->
        Column(Modifier.padding(pad).padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            AccountPicker(leaf, account, "اختر الحساب") { account = it }
            DateRangeFields(from, to, { from = it }, { to = it })
            LabeledSwitch("كل الفروع المسموحة", all) { all = it }
            Button(modifier = Modifier.fillMaxWidth(), onClick = {
                val acc = account
                if (acc == null) { ctx.toast("اختر الحساب أولاً"); return@Button }
                scope.launch {
                    runCatching {
                        vm.svc.statement(
                            acc.id, Dates.parse(from) ?: error("تاريخ البداية غير صحيح"),
                            Dates.parse(to) ?: error("تاريخ النهاية غير صحيح"), all
                        )
                    }.onSuccess { result = it }.onFailure { ctx.toast(it.message ?: "حدث خطأ") }
                }
            }) { Text("عرض") }

            result?.let { (opening, rows) ->
                var bal = opening
                val withBal = rows.map { bal += it.debit - it.credit; it to bal }
                Text("الرصيد الافتتاحي: ${Money.signed(opening)}", fontWeight = FontWeight.Bold)
                LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(withBal) { (r, b) ->
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(10.dp)) {
                                Text("${Dates.format(r.date)} • قيد ${r.entryNo}", style = MaterialTheme.typography.bodySmall)
                                Text(r.description + (r.note?.let { " — $it" } ?: ""), style = MaterialTheme.typography.bodyMedium)
                                Row(Modifier.fillMaxWidth()) {
                                    Cell("مدين", if (r.debit > 0) Money.format(r.debit) else "-", Modifier.weight(1f))
                                    Cell("دائن", if (r.credit > 0) Money.format(r.credit) else "-", Modifier.weight(1f))
                                    Cell("الرصيد", Money.signed(b), Modifier.weight(1f))
                                }
                            }
                        }
                    }
                    item { Text("الرصيد الختامي: ${Money.signed(bal)}", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 6.dp)) }
                }
            }
        }
    }
}
