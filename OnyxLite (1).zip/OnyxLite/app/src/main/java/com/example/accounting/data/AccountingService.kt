package com.example.accounting.data

import androidx.room.withTransaction
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

data class LineInput(val accountId: Long, val debit: Long, val credit: Long, val note: String?)

/**
 * طبقة منطق العمل: كل فحص الصلاحيات والتوازن والترحيل هنا (وليس في الواجهة).
 */
@OptIn(ExperimentalCoroutinesApi::class)
@Singleton
class AccountingService @Inject constructor(private val db: AppDatabase, val sm: SessionManager) {

    // ---------- تدفقات للواجهة ----------
    val accountsFlow: Flow<List<Account>> = db.accountDao().observeAll()
    val rolesFlow: Flow<List<Role>> = db.roleDao().observeAll()
    val allBranchesFlow: Flow<List<Branch>> = db.branchDao().observeAll()
    val usersFlow: Flow<List<UserRow>> = db.userDao().observeRows()
    val entriesFlow: Flow<List<EntryRow>> = sm.session.filterNotNull()
        .map { it.currentBranchId }.distinctUntilChanged()
        .flatMapLatest { db.entryDao().observe(it) }
    val myBranchesFlow: Flow<List<Branch>> = sm.session.filterNotNull().flatMapLatest { s ->
        db.branchDao().observeAll().map { l -> l.filter { it.id in s.allowedBranchIds && it.isActive } }
    }

    // ---------- أدوات داخلية ----------
    private fun s(): Session = sm.session.value ?: error("يجب تسجيل الدخول أولاً")
    private fun need(p: Permission) { check(s().permissions.contains(p)) { "لا تملك الصلاحية المطلوبة" } }

    private suspend fun audit(action: String, type: String, id: Long?) {
        val s = s()
        db.auditDao().insert(AuditLog(userId = s.user.id, branchId = s.currentBranchId, action = action, entityType = type, entityId = id))
    }

    // ---------- التهيئة الأولى ----------
    private val seedMutex = Mutex()
    private var seeded = false

    private suspend fun ensureSeeded() = seedMutex.withLock {
        if (seeded) return@withLock
        db.withTransaction {
            if (db.userDao().count() == 0) {
                val branchId = db.branchDao().insert(Branch(code = "01", nameAr = "الفرع الرئيسي"))
                val all = Permission.values().toSet()
                val roles = listOf(
                    "مدير النظام" to all,
                    "محاسب" to setOf(
                        Permission.ACCOUNT_VIEW, Permission.ACCOUNT_EDIT, Permission.ENTRY_VIEW, Permission.ENTRY_CREATE,
                        Permission.ENTRY_EDIT, Permission.ENTRY_DELETE_DRAFT, Permission.ENTRY_POST, Permission.REPORT_VIEW
                    ),
                    "أمين صندوق" to setOf(
                        Permission.ACCOUNT_VIEW, Permission.ENTRY_VIEW, Permission.ENTRY_CREATE, Permission.ENTRY_EDIT,
                        Permission.ENTRY_DELETE_DRAFT, Permission.REPORT_VIEW
                    ),
                    "مراجع" to setOf(Permission.ACCOUNT_VIEW, Permission.ENTRY_VIEW, Permission.ENTRY_POST, Permission.REPORT_VIEW)
                )
                var adminRole = 0L
                roles.forEachIndexed { i, (name, perms) ->
                    val rid = db.roleDao().insert(Role(name = name))
                    db.roleDao().insertPermissions(perms.map { RolePermission(rid, it) })
                    if (i == 0) adminRole = rid
                }
                val salt = PasswordHasher.newSalt()
                val uid = db.userDao().insert(
                    User(
                        username = "admin", fullName = "مدير النظام",
                        passwordHash = PasswordHasher.hash("admin123", salt), salt = salt,
                        roleId = adminRole, mustChangePassword = true
                    )
                )
                db.userDao().addBranches(listOf(UserBranch(uid, branchId)))
                seedChartOfAccounts(db.accountDao())
            }
        }
        seeded = true
    }

    // ---------- الدخول ----------
    /** يعيد true إن كان يجب تغيير كلمة المرور. */
    suspend fun login(username: String, password: String): Boolean {
        ensureSeeded()
        val u = db.userDao().byUsername(username)
        if (u == null || !u.isActive || !PasswordHasher.verify(password, u.salt, u.passwordHash))
            error("اسم المستخدم أو كلمة المرور غير صحيحة")
        val perms = db.roleDao().permissions(u.roleId).toSet()
        val branches = db.branchDao().byIds(db.userDao().branchIds(u.id)).filter { it.isActive }
        check(branches.isNotEmpty()) { "المستخدم غير مرتبط بأي فرع فعّال" }
        sm.start(Session(u, perms, branches.map { it.id }.toSet(), branches.first().id))
        audit("LOGIN", "User", u.id)
        return u.mustChangePassword
    }

    fun logout() = sm.clear()
    fun switchBranch(id: Long) = sm.switchBranch(id)

    suspend fun changePassword(newPassword: String) {
        require(newPassword.length >= 6) { "كلمة المرور 6 أحرف على الأقل" }
        require(newPassword != "admin123") { "اختر كلمة مرور مختلفة عن الافتراضية" }
        val u = db.userDao().get(s().user.id) ?: error("المستخدم غير موجود")
        val salt = PasswordHasher.newSalt()
        val nu = u.copy(passwordHash = PasswordHasher.hash(newPassword, salt), salt = salt, mustChangePassword = false)
        db.userDao().update(nu)
        sm.updateUser(nu)
        audit("PASSWORD", "User", u.id)
    }

    // ---------- دليل الحسابات ----------
    suspend fun saveAccount(a: Account) {
        need(Permission.ACCOUNT_EDIT)
        require(a.code.isNotBlank() && a.nameAr.isNotBlank()) { "الرمز والاسم مطلوبان" }
        db.withTransaction {
            val dao = db.accountDao()
            dao.byCode(a.code)?.let { require(it.id == a.id) { "الرمز مستخدم لحساب آخر" } }
            var acc = a
            if (a.parentId != null) {
                val p = dao.get(a.parentId) ?: error("الحساب الأب غير موجود")
                require(dao.lineCount(p.id) == 0) { "الحساب الأب عليه حركات، لا يمكن إضافة حسابات تحته" }
                var cur: Account? = p
                while (cur != null) {
                    require(a.id == 0L || cur.id != a.id) { "لا يمكن جعل الحساب تابعاً لنفسه أو لأحد فروعه" }
                    cur = cur.parentId?.let { dao.get(it) }
                }
                acc = a.copy(type = p.type)
                if (p.isLeaf) dao.update(p.copy(isLeaf = false))
            }
            if (a.id == 0L) {
                audit("CREATE", "Account", dao.insert(acc))
            } else {
                val old = dao.get(a.id) ?: error("الحساب غير موجود")
                if (dao.lineCount(a.id) > 0) {
                    require(
                        old.type == acc.type && old.normalBalance == acc.normalBalance &&
                            old.isLeaf == acc.isLeaf && old.parentId == acc.parentId
                    ) { "الحساب عليه حركات، لا يمكن تغيير نوعه أو طبيعته أو موقعه" }
                }
                require(!(acc.isLeaf && dao.childCount(a.id) > 0)) { "الحساب له حسابات فرعية، لا يمكن جعله حساباً فرعياً" }
                dao.update(acc)
                audit("UPDATE", "Account", a.id)
            }
        }
    }

    // ---------- القيود ----------
    private suspend fun validateLines(lines: List<LineInput>) {
        require(lines.size >= 2) { "القيد يحتاج سطرين على الأقل" }
        require(lines.all { it.debit >= 0 && it.credit >= 0 && (it.debit > 0) != (it.credit > 0) }) {
            "كل سطر يجب أن يكون مديناً أو دائناً بمبلغ أكبر من صفر"
        }
        require(lines.sumOf { it.debit } == lines.sumOf { it.credit }) { "القيد غير متوازن" }
        val ids = lines.map { it.accountId }.distinct()
        val accs = db.accountDao().byIds(ids)
        require(accs.size == ids.size && accs.all { it.isLeaf && it.isActive }) { "يجب أن تكون كل الحسابات فرعية وفعّالة" }
    }

    suspend fun loadEntry(id: Long): Pair<JournalEntry, List<JournalLine>> {
        need(Permission.ENTRY_VIEW)
        val e = db.entryDao().get(id) ?: error("القيد غير موجود")
        sm.requireBranch(e.branchId)
        return e to db.lineDao().byEntry(id)
    }

    /** حفظ كمسودة (جديد: entryId = 0). */
    suspend fun saveEntry(entryId: Long, date: Long, description: String, lines: List<LineInput>): Long {
        require(description.isNotBlank()) { "البيان مطلوب" }
        validateLines(lines)
        val s = s()
        return db.withTransaction {
            val rows = { id: Long -> lines.map { JournalLine(entryId = id, accountId = it.accountId, debit = it.debit, credit = it.credit, note = it.note) } }
            if (entryId == 0L) {
                need(Permission.ENTRY_CREATE)
                val id = db.entryDao().insert(
                    JournalEntry(
                        entryNo = db.entryDao().nextNo(s.currentBranchId), date = date,
                        description = description.trim(), branchId = s.currentBranchId, createdBy = s.user.id
                    )
                )
                db.lineDao().insertAll(rows(id))
                audit("CREATE", "JournalEntry", id)
                id
            } else {
                need(Permission.ENTRY_EDIT)
                val e = db.entryDao().get(entryId) ?: error("القيد غير موجود")
                sm.requireBranch(e.branchId)
                check(e.status == EntryStatus.DRAFT) { "لا يمكن تعديل قيد مرحّل" }
                db.entryDao().update(e.copy(date = date, description = description.trim()))
                db.lineDao().deleteByEntry(entryId)
                db.lineDao().insertAll(rows(entryId))
                audit("UPDATE", "JournalEntry", entryId)
                entryId
            }
        }
    }

    suspend fun postEntry(id: Long) {
        need(Permission.ENTRY_POST)
        db.withTransaction {
            val e = db.entryDao().get(id) ?: error("القيد غير موجود")
            sm.requireBranch(e.branchId)
            check(e.status == EntryStatus.DRAFT) { "القيد ليس مسودة" }
            val lines = db.lineDao().byEntry(id)
            check(lines.size >= 2 && lines.sumOf { it.debit } == lines.sumOf { it.credit }) { "القيد غير متوازن" }
            db.entryDao().update(e.copy(status = EntryStatus.POSTED, postedBy = s().user.id))
            audit("POST", "JournalEntry", id)
        }
    }

    suspend fun reverseEntry(id: Long) {
        need(Permission.ENTRY_REVERSE)
        db.withTransaction {
            val e = db.entryDao().get(id) ?: error("القيد غير موجود")
            sm.requireBranch(e.branchId)
            check(e.status == EntryStatus.POSTED && e.reversedEntryId == null) { "يمكن عكس القيود المرحّلة الأصلية فقط" }
            val s = s()
            val newId = db.entryDao().insert(
                JournalEntry(
                    entryNo = db.entryDao().nextNo(e.branchId), date = Dates.today(),
                    description = "عكس القيد رقم ${e.entryNo}", status = EntryStatus.POSTED,
                    reversedEntryId = id, branchId = e.branchId, createdBy = s.user.id, postedBy = s.user.id
                )
            )
            db.lineDao().insertAll(
                db.lineDao().byEntry(id).map {
                    JournalLine(entryId = newId, accountId = it.accountId, debit = it.credit, credit = it.debit, note = it.note)
                }
            )
            db.entryDao().update(e.copy(status = EntryStatus.REVERSED))
            audit("REVERSE", "JournalEntry", id)
        }
    }

    suspend fun deleteDraft(id: Long) {
        need(Permission.ENTRY_DELETE_DRAFT)
        db.withTransaction {
            val e = db.entryDao().get(id) ?: error("القيد غير موجود")
            sm.requireBranch(e.branchId)
            check(e.status == EntryStatus.DRAFT) { "لا يمكن حذف قيد مرحّل، استخدم العكس" }
            db.entryDao().delete(id)
            audit("DELETE", "JournalEntry", id)
        }
    }

    // ---------- التقارير ----------
    private fun scope(all: Boolean): List<Long> = s().let { if (all) it.allowedBranchIds.toList() else listOf(it.currentBranchId) }

    suspend fun trialBalance(from: Long, to: Long, allBranches: Boolean): List<TrialRow> {
        need(Permission.REPORT_VIEW)
        return db.lineDao().trialBalance(scope(allBranches), from, to)
    }

    /** يعيد (الرصيد الافتتاحي، الحركات). */
    suspend fun statement(accountId: Long, from: Long, to: Long, allBranches: Boolean): Pair<Long, List<StmtRow>> {
        need(Permission.REPORT_VIEW)
        val ids = scope(allBranches)
        return db.lineDao().opening(accountId, ids, from) to db.lineDao().statement(accountId, ids, from, to)
    }

    // ---------- المستخدمون والفروع ----------
    suspend fun userBranchIds(userId: Long): Set<Long> = db.userDao().branchIds(userId).toSet()

    suspend fun saveUser(id: Long, username: String, fullName: String, password: String, roleId: Long, branchIds: Set<Long>, active: Boolean) {
        need(Permission.USER_MANAGE)
        require(username.isNotBlank() && fullName.isNotBlank()) { "اسم المستخدم والاسم الكامل مطلوبان" }
        require(branchIds.isNotEmpty()) { "اختر فرعاً واحداً على الأقل" }
        require(id != s().user.id || active) { "لا يمكنك تعطيل حسابك" }
        db.withTransaction {
            val uid: Long
            if (id == 0L) {
                require(password.length >= 6) { "كلمة المرور 6 أحرف على الأقل" }
                require(db.userDao().byUsername(username.trim()) == null) { "اسم المستخدم موجود مسبقاً" }
                val salt = PasswordHasher.newSalt()
                uid = db.userDao().insert(
                    User(
                        username = username.trim(), fullName = fullName.trim(), passwordHash = PasswordHasher.hash(password, salt),
                        salt = salt, roleId = roleId, isActive = active, mustChangePassword = true
                    )
                )
            } else {
                uid = id
                val u = db.userDao().get(id) ?: error("المستخدم غير موجود")
                var nu = u.copy(fullName = fullName.trim(), roleId = roleId, isActive = active)
                if (password.isNotEmpty()) {
                    require(password.length >= 6) { "كلمة المرور 6 أحرف على الأقل" }
                    val salt = PasswordHasher.newSalt()
                    nu = nu.copy(passwordHash = PasswordHasher.hash(password, salt), salt = salt, mustChangePassword = true)
                }
                db.userDao().update(nu)
            }
            db.userDao().clearBranches(uid)
            db.userDao().addBranches(branchIds.map { UserBranch(uid, it) })
            audit(if (id == 0L) "CREATE" else "UPDATE", "User", uid)
        }
    }

    suspend fun saveBranch(id: Long, code: String, name: String, active: Boolean) {
        need(Permission.BRANCH_MANAGE)
        require(code.isNotBlank() && name.isNotBlank()) { "الرمز والاسم مطلوبان" }
        db.withTransaction {
            if (id == 0L) {
                val nid = db.branchDao().insert(Branch(code = code.trim(), nameAr = name.trim(), isActive = active))
                db.userDao().addBranches(listOf(UserBranch(s().user.id, nid)))
                sm.addBranch(nid)
                audit("CREATE", "Branch", nid)
            } else {
                val b = db.branchDao().get(id) ?: error("الفرع غير موجود")
                require(active || id != s().currentBranchId) { "لا يمكن تعطيل الفرع الحالي" }
                db.branchDao().update(b.copy(code = code.trim(), nameAr = name.trim(), isActive = active))
                audit("UPDATE", "Branch", id)
            }
        }
    }
}
