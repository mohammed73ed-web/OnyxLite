@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.accounting.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.example.accounting.data.*
import kotlinx.coroutines.launch
import kotlin.system.exitProcess

private data class UserEdit(val row: UserRow?, val branchIds: Set<Long>)

@Composable
fun UsersScreen(onBack: () -> Unit, vm: MainVm = hiltViewModel()) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val users by vm.svc.usersFlow.collectAsState(initial = emptyList<UserRow>())
    val roles by vm.svc.rolesFlow.collectAsState(initial = emptyList<Role>())
    val branches by vm.svc.allBranchesFlow.collectAsState(initial = emptyList<Branch>())
    var editing by remember { mutableStateOf<UserEdit?>(null) }

    AppScaffold(
        "المستخدمون", onBack,
        fab = { FloatingActionButton(onClick = { editing = UserEdit(null, emptySet()) }) { Icon(Icons.Default.Add, "مستخدم جديد") } }
    ) { pad ->
        LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(users, key = { it.user.id }) { r ->
                Card(Modifier.fillMaxWidth().clickable {
                    scope.launch { editing = UserEdit(r, vm.svc.userBranchIds(r.user.id)) }
                }) {
                    Column(Modifier.padding(12.dp)) {
                        Text("${r.user.fullName} (${r.user.username})", fontWeight = FontWeight.Bold)
                        Text("${r.roleName}${if (r.user.isActive) "" else " • معطّل"}", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }

    editing?.let { ed ->
        UserDialog(ed, roles, branches, { editing = null }) { id, un, fn, pw, role, bs, act ->
            scope.launch {
                runCatching { vm.svc.saveUser(id, un, fn, pw, role, bs, act) }
                    .onSuccess { editing = null }
                    .onFailure { ctx.toast(it.message ?: "حدث خطأ") }
            }
        }
    }
}

@Composable
private fun UserDialog(
    ed: UserEdit, roles: List<Role>, branches: List<Branch>, onDismiss: () -> Unit,
    onSave: (Long, String, String, String, Long, Set<Long>, Boolean) -> Unit
) {
    val u = ed.row?.user
    var username by remember { mutableStateOf(u?.username ?: "") }
    var fullName by remember { mutableStateOf(u?.fullName ?: "") }
    var password by remember { mutableStateOf("") }
    var roleId by remember { mutableStateOf(u?.roleId ?: roles.firstOrNull()?.id ?: 0L) }
    var selected by remember { mutableStateOf(ed.branchIds) }
    var active by remember { mutableStateOf(u?.isActive ?: true) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (u == null) "مستخدم جديد" else "تعديل مستخدم") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(username, { username = it }, label = { Text("اسم المستخدم") }, singleLine = true, enabled = u == null)
                OutlinedTextField(fullName, { fullName = it }, label = { Text("الاسم الكامل") }, singleLine = true)
                OutlinedTextField(
                    password, { password = it },
                    label = { Text(if (u == null) "كلمة المرور" else "كلمة مرور جديدة (اتركها فارغة للإبقاء)") },
                    singleLine = true
                )
                Text("الدور", style = MaterialTheme.typography.labelMedium)
                roles.forEach { r ->
                    Row(Modifier.fillMaxWidth().clickable { roleId = r.id }, verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = roleId == r.id, onClick = { roleId = r.id })
                        Text(r.name)
                    }
                }
                Text("الفروع المسموحة", style = MaterialTheme.typography.labelMedium)
                branches.forEach { b ->
                    Row(
                        Modifier.fillMaxWidth().clickable { selected = if (b.id in selected) selected - b.id else selected + b.id },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(checked = b.id in selected, onCheckedChange = { selected = if (it) selected + b.id else selected - b.id })
                        Text(b.nameAr)
                    }
                }
                LabeledSwitch("فعّال", active) { active = it }
            }
        },
        confirmButton = {
            TextButton(onClick = { onSave(u?.id ?: 0L, username, fullName, password, roleId, selected, active) }) { Text("حفظ") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

@Composable
fun BranchesScreen(onBack: () -> Unit, vm: MainVm = hiltViewModel()) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val branches by vm.svc.allBranchesFlow.collectAsState(initial = emptyList<Branch>())
    var editing by remember { mutableStateOf<Branch?>(null) }
    var creating by remember { mutableStateOf(false) }

    AppScaffold(
        "الفروع", onBack,
        fab = { FloatingActionButton(onClick = { creating = true }) { Icon(Icons.Default.Add, "فرع جديد") } }
    ) { pad ->
        LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(branches, key = { it.id }) { b ->
                Card(Modifier.fillMaxWidth().clickable { editing = b }) {
                    Column(Modifier.padding(12.dp)) {
                        Text("${b.code} - ${b.nameAr}", fontWeight = FontWeight.Bold)
                        if (!b.isActive) Text("معطّل", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }

    if (creating || editing != null) {
        val b = editing
        var code by remember { mutableStateOf(b?.code ?: "") }
        var name by remember { mutableStateOf(b?.nameAr ?: "") }
        var active by remember { mutableStateOf(b?.isActive ?: true) }
        AlertDialog(
            onDismissRequest = { creating = false; editing = null },
            title = { Text(if (b == null) "فرع جديد" else "تعديل فرع") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(code, { code = it }, label = { Text("الرمز") }, singleLine = true)
                    OutlinedTextField(name, { name = it }, label = { Text("اسم الفرع") }, singleLine = true)
                    LabeledSwitch("فعّال", active) { active = it }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    scope.launch {
                        runCatching { vm.svc.saveBranch(b?.id ?: 0L, code, name, active) }
                            .onSuccess { creating = false; editing = null }
                            .onFailure { ctx.toast(it.message ?: "حدث خطأ") }
                    }
                }) { Text("حفظ") }
            },
            dismissButton = { TextButton(onClick = { creating = false; editing = null }) { Text("إلغاء") } }
        )
    }
}

@Composable
fun BackupScreen(onBack: () -> Unit, vm: MainVm = hiltViewModel()) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var restoreUri by remember { mutableStateOf<Uri?>(null) }

    val create = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        if (uri != null) scope.launch {
            runCatching { vm.backup.backup(uri) }
                .onSuccess { ctx.toast("تم إنشاء النسخة الاحتياطية") }
                .onFailure { ctx.toast(it.message ?: "فشل النسخ") }
        }
    }
    val open = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { restoreUri = it }

    AppScaffold("نسخ احتياطي واستعادة", onBack) { pad ->
        Column(Modifier.padding(pad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("النسخة الاحتياطية تحتوي كل بيانات الشركة وكلمات المرور المجزّأة. احفظها في مكان آمن.")
            Button(onClick = { create.launch("accounting-backup-${Dates.format(Dates.today())}.db") }, Modifier.fillMaxWidth()) {
                Text("إنشاء نسخة احتياطية")
            }
            OutlinedButton(onClick = { open.launch(arrayOf("*/*")) }, Modifier.fillMaxWidth()) { Text("استعادة من نسخة") }
        }
    }

    restoreUri?.let { uri ->
        ConfirmDialog(
            "استعادة نسخة",
            "ستُستبدل كل البيانات الحالية بمحتوى النسخة، وسيُغلق التطبيق بعد الانتهاء. متابعة؟",
            onConfirm = {
                restoreUri = null
                scope.launch {
                    runCatching { vm.backup.restore(uri) }
                        .onSuccess { ctx.toast("تمت الاستعادة. افتح التطبيق من جديد."); exitProcess(0) }
                        .onFailure { ctx.toast(it.message ?: "فشلت الاستعادة") }
                }
            },
            onDismiss = { restoreUri = null }
        )
    }
}
